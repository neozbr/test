
import React, { useEffect } from 'react';
import Navbar from '../components/Navbar';
import Header from '../components/Header';
import ProblemSection from '../components/ProblemSection';
import BenefitsSection from '../components/BenefitsSection';
import VideoSection from '../components/VideoSection';
import TestimonialsSection from '../components/TestimonialsSection';
import GuaranteeSection from '../components/GuaranteeSection';
import PricingSection from '../components/PricingSection';
import FAQSection from '../components/FAQSection';
import Footer from '../components/Footer';

const Index = () => {
  // Scroll animation for sections
  useEffect(() => {
    const handleScroll = () => {
      const sections = document.querySelectorAll('.fade-in-section');
      
      sections.forEach(section => {
        const sectionTop = section.getBoundingClientRect().top;
        const windowHeight = window.innerHeight;
        
        if (sectionTop < windowHeight * 0.85) {
          section.classList.add('visible');
        }
      });
    };
    
    window.addEventListener('scroll', handleScroll);
    // Run once immediately to check for elements in initial viewport
    setTimeout(handleScroll, 100);
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);
  
  return (
    <div className="min-h-screen">
      <Navbar />
      <Header />
      
      <div className="fade-in-section">
        <ProblemSection />
      </div>
      
      <div className="fade-in-section">
        <BenefitsSection />
      </div>
      
      <div className="fade-in-section">
        <VideoSection />
      </div>
      
      <div className="fade-in-section">
        <TestimonialsSection />
      </div>
      
      <div className="fade-in-section">
        <GuaranteeSection />
      </div>
      
      <div className="fade-in-section">
        <PricingSection />
      </div>
      
      <div className="fade-in-section">
        <FAQSection />
      </div>
      
      <Footer />
    </div>
  );
};

export default Index;
