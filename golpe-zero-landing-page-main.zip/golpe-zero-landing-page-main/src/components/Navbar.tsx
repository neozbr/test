
import React, { useState, useEffect } from 'react';
import { Shield, Menu, X } from 'lucide-react';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${
      isScrolled ? 'bg-white shadow-md py-2' : 'bg-transparent py-4'
    }`}>
      <div className="container mx-auto">
        <div className="flex justify-between items-center">
          <a href="#" className="flex items-center">
            <Shield className={`mr-2 ${isScrolled ? 'text-security-blue' : 'text-security-blue'}`} size={28} />
            <span className={`font-bold text-xl ${isScrolled ? 'text-security-darkBlue' : 'text-security-darkBlue'}`}>
              Guia Anti-Golpes
            </span>
          </a>
          
          {/* Desktop menu */}
          <div className="hidden md:flex items-center space-x-8">
            <a href="#benefits" className={`${isScrolled ? 'text-gray-700' : 'text-gray-800'} hover:text-security-blue transition-colors`}>
              Benefícios
            </a>
            <a href="#testimonials" className={`${isScrolled ? 'text-gray-700' : 'text-gray-800'} hover:text-security-blue transition-colors`}>
              Depoimentos
            </a>
            <a href="#faq" className={`${isScrolled ? 'text-gray-700' : 'text-gray-800'} hover:text-security-blue transition-colors`}>
              FAQ
            </a>
            <a href="https://pay.hotmart.com/F99031339U" className="btn-primary py-2 px-5 inline-block">
              Comprar Agora
            </a>
          </div>
          
          {/* Mobile menu button */}
          <button 
            className="md:hidden text-gray-700"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
        
        {/* Mobile menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white mt-4 py-4 px-2 rounded-lg shadow-lg">
            <div className="flex flex-col space-y-3">
              <a 
                href="#benefits" 
                className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Benefícios
              </a>
              <a 
                href="#testimonials" 
                className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Depoimentos
              </a>
              <a 
                href="#faq" 
                className="px-4 py-2 text-gray-700 hover:bg-gray-100 rounded-md"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                FAQ
              </a>
              <a 
                href="https://pay.hotmart.com/F99031339U" 
                className="px-4 py-2 bg-security-orange text-white rounded-md font-medium text-center"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Comprar Agora
              </a>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
