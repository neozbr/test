
import React from 'react';
import { Check, DollarSign } from 'lucide-react';

const PricingSection = () => {
  return (
    <section className="py-16 bg-white" id="pricing">
      <div className="container mx-auto">
        <h2 className="section-title text-center">A Melhor Oferta para Sua Segurança Digital</h2>
        
        <div className="max-w-2xl mx-auto bg-white rounded-xl shadow-2xl overflow-hidden">
          <div className="bg-security-blue text-white p-6 md:p-8">
            <div className="flex items-center justify-center mb-4">
              <DollarSign className="mr-2" size={28} />
              <h3 className="text-2xl md:text-3xl font-bold">Oferta Especial</h3>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center">
                <span className="text-xl line-through opacity-75">R$ 69,90</span>
                <span className="text-3xl md:text-5xl font-bold ml-3">R$ 39,90</span>
              </div>
              <p className="mt-2 text-security-lightBlue">Pagamento único - sem mensalidades</p>
            </div>
          </div>
          
          <div className="p-6 md:p-8">
            <ul className="space-y-4 mb-8">
              <li className="flex items-start">
                <Check className="text-security-green flex-shrink-0 mt-1" size={20} />
                <span className="ml-3">Acesso imediato ao eBook completo</span>
              </li>
              <li className="flex items-start">
                <Check className="text-security-green flex-shrink-0 mt-1" size={20} />
                <span className="ml-3">Todas as dicas de segurança digital</span>
              </li>
              <li className="flex items-start">
                <Check className="text-security-green flex-shrink-0 mt-1" size={20} />
                <span className="ml-3">Garantia de 7 dias</span>
              </li>
              <li className="flex items-start">
                <Check className="text-security-green flex-shrink-0 mt-1" size={20} />
                <span className="ml-3">Acesso para sempre, sem prazo de validade</span>
              </li>
            </ul>
            
            <div className="text-center">
              <a href="https://pay.hotmart.com/F99031339U" className="btn-primary block w-full max-w-full mx-auto">
                Compre Agora e Comece a Proteger-se Já!
              </a>
              <p className="mt-4 text-sm text-gray-500">
                Pagamento seguro via cartão de crédito, PIX ou boleto
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PricingSection;
