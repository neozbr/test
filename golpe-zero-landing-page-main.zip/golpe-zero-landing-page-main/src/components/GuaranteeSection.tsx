
import React from 'react';
import { Shield, Lock } from 'lucide-react';

const GuaranteeSection = () => {
  return (
    <section className="py-16 bg-security-lightBlue" id="guarantee">
      <div className="container mx-auto">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="section-title">Compra 100% Segura!</h2>
          
          <div className="flex justify-center mb-8">
            <Shield className="text-security-blue" size={64} />
          </div>
          
          <p className="text-lg md:text-xl mb-8 text-gray-700">
            Seu pagamento é 100% seguro e protegido. Se por qualquer motivo você não ficar 
            satisfeito, oferecemos uma garantia de devolução de 7 dias. Sem perguntas!
          </p>
          
          <div className="flex flex-col md:flex-row items-center justify-center gap-6 mb-8">
            <div className="flex items-center bg-white py-3 px-6 rounded-full shadow-md">
              <Lock className="text-security-blue mr-2" size={20} />
              <span className="font-medium">Pagamento Seguro</span>
            </div>
            <div className="flex items-center bg-white py-3 px-6 rounded-full shadow-md">
              <Shield className="text-security-blue mr-2" size={20} />
              <span className="font-medium">Garantia de 7 dias</span>
            </div>
          </div>
          
          <a href="#pricing" className="btn-primary mx-auto">
            Adquira Agora Com Total Segurança!
          </a>
        </div>
      </div>
    </section>
  );
};

export default GuaranteeSection;
