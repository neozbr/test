
import React from 'react';
import { Lock, Shield } from 'lucide-react';

const Header = () => {
  return (
    <header className="bg-security-gradient py-16 md:py-24">
      <div className="container mx-auto flex flex-col md:flex-row items-center">
        <div className="md:w-1/2 mb-10 md:mb-0">
          <div className="flex items-center mb-6">
            <Shield className="text-security-blue mr-2" size={36} />
            <h3 className="text-xl md:text-2xl font-bold text-security-blue">Guia Anti-Golpes</h3>
          </div>
          <h1 className="text-4xl md:text-5xl font-extrabold mb-6 text-security-darkBlue leading-tight">
            Está Cansado de Tomar Golpe? Aprenda a Se Proteger no Telegram e Sites Agora!
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-700">
            Compre agora e aprenda as sacadas que você precisa para nunca mais cair em golpes!
          </p>
          <a href="https://pay.hotmart.com/F99031339U" className="btn-primary inline-block">
            <span>Compre Agora por Apenas R$ 39,90</span>
            <Lock className="ml-2 inline-block" size={20} />
          </a>
        </div>
        <div className="md:w-1/2 flex justify-center md:justify-end animate-bounce-slow">
          <div className="relative">
            <div className="absolute inset-0 bg-security-blue/10 rounded-xl transform rotate-3"></div>
            <img 
              src="/lovable-uploads/ae32bb22-59c7-49f4-9c4f-757bb672ce14.png" 
              alt="eBook Anti-Golpes" 
              className="w-64 md:w-80 h-auto rounded-lg shadow-xl relative z-10" 
            />
            <div className="absolute top-0 right-0 transform translate-x-3 -translate-y-3 bg-security-orange text-white py-2 px-4 rounded-full shadow-lg">
              <span className="font-bold">E-book</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
