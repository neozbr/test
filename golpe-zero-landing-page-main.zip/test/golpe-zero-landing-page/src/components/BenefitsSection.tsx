
import React from 'react';
import { Check } from 'lucide-react';

const BenefitsSection = () => {
  const benefits = [
    "Como Não Correr Riscos ao Abrir Arquivos no Seu PC",
    "Como Evitar Golpes ao Comprar em Sites",
    "Dicas para Identificar Golpes no Telegram",
    "Proteja Seus Dados Pessoais e Bancários de Forma Eficiente",
    "Evite Riscos ao Compartilhar Informações Pessoais Online",
    "E Várias Dicas Extras que Você Não Conhece!"
  ];

  return (
    <section className="py-16 bg-gray-50" id="benefits">
      <div className="container mx-auto">
        <h2 className="section-title text-center">O Que Você Vai Aprender</h2>
        
        <p className="text-lg md:text-xl text-center max-w-3xl mx-auto mb-12 text-gray-700">
          Este guia traz dicas e sacadas que você precisa conhecer para estar protegido contra fraudes online.
        </p>
        
        <div className="grid md:grid-cols-2 gap-6 max-w-4xl mx-auto mb-12">
          {benefits.map((benefit, index) => (
            <div key={index} className="flex items-start p-4 bg-white rounded-lg shadow-md">
              <Check className="text-security-green flex-shrink-0 mt-1" size={24} />
              <p className="ml-3 text-lg">{benefit}</p>
            </div>
          ))}
        </div>
        
        <div className="text-center">
          <a href="#pricing" className="btn-primary mx-auto">
            Comece a Proteger sua Vida Digital Hoje Mesmo!
          </a>
        </div>
      </div>
    </section>
  );
};

export default BenefitsSection;
