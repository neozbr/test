
import React from 'react';

const VideoSection = () => {
  return (
    <section className="py-16 bg-gray-50" id="video">
      <div className="container mx-auto px-4">
        <h2 className="section-title text-center mb-10">Confira nosso video sobre</h2>
        
        <div className="max-w-4xl mx-auto">
          <div className="relative w-full" style={{ paddingBottom: '56.25%' }}>
            <iframe 
              className="absolute top-0 left-0 w-full h-full rounded-xl shadow-xl"
              src="https://www.youtube.com/embed/Xes1M9xTLHw" 
              title="Vídeo sobre proteção contra golpes online"
              frameBorder="0" 
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
              allowFullScreen
            ></iframe>
          </div>
        </div>
        
        <div className="text-center mt-10">
          <a href="https://pay.hotmart.com/F99031339U" className="btn-primary">
            Proteja-se Agora - Adquira o eBook!
          </a>
        </div>
      </div>
    </section>
  );
};

export default VideoSection;
