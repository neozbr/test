
import React from 'react';
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger
} from "@/components/ui/accordion";

const FAQSection = () => {
  const faqs = [
    {
      question: "O que vou aprender no eBook?",
      answer: "O guia traz dicas práticas para evitar golpes online, proteger sua privacidade e segurança, identificar sites fraudulentos, evitar golpes no Telegram e muito mais!"
    },
    {
      question: "Posso pagar por boleto?",
      answer: "Sim, aceitamos pagamento por boleto bancário, além de cartão de crédito e PIX."
    },
    {
      question: "Posso pedir reembolso?",
      answer: "Sim, garantimos seu reembolso dentro de 7 dias caso você não esteja satisfeito com o conteúdo do eBook."
    },
    {
      question: "Como recebo o eBook após a compra?",
      answer: "Após a confirmação do pagamento, você receberá um email com o link para download do eBook em formato PDF."
    },
    {
      question: "O conteúdo é atualizado?",
      answer: "Sim! O conteúdo é regularmente atualizado para incluir informações sobre os golpes mais recentes e as melhores práticas de segurança digital."
    }
  ];

  return (
    <section className="py-16 bg-gray-50" id="faq">
      <div className="container mx-auto">
        <h2 className="section-title text-center mb-12">Perguntas Frequentes</h2>
        
        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="bg-white rounded-lg shadow-md">
                <AccordionTrigger className="px-6 py-4 text-lg font-medium text-left text-gray-800 hover:text-security-blue">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="px-6 pb-4 text-gray-700">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
        
        <div className="text-center mt-12">
          <a href="#pricing" className="btn-primary mx-auto">
            Pronto para Proteger-se? Compre Agora!
          </a>
        </div>
      </div>
    </section>
  );
};

export default FAQSection;
