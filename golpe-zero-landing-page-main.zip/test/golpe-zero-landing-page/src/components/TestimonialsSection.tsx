
import React from 'react';
import { Star } from 'lucide-react';

const TestimonialsSection = () => {
  const testimonials = [
    {
      text: "Comprei o guia e agora me sinto muito mais seguro online. As dicas são práticas e fáceis de seguir!",
      author: "João P.",
      stars: 5
    },
    {
      text: "Já tomei alguns golpes no passado, mas esse guia me ajudou a nunca mais cair nas mesmas armadilhas. Vale cada centavo!",
      author: "Maria T.",
      stars: 5
    },
    {
      text: "Minha família já perdeu dinheiro com golpes online. Com este guia consegui ensinar meus pais a se protegerem.",
      author: "Carlos S.",
      stars: 5
    }
  ];

  return (
    <section className="py-16 bg-white" id="testimonials">
      <div className="container mx-auto">
        <h2 className="section-title text-center">Veja o Que Quem Já Comprou Está Dizendo</h2>
        
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto mb-12">
          {testimonials.map((testimonial, index) => (
            <div key={index} className="bg-gray-50 p-6 rounded-lg shadow-lg">
              <div className="flex mb-4">
                {Array.from({ length: testimonial.stars }).map((_, i) => (
                  <Star key={i} className="text-yellow-400 fill-yellow-400" size={20} />
                ))}
              </div>
              <p className="mb-4 text-gray-700">"{testimonial.text}"</p>
              <p className="font-bold text-security-darkBlue">- {testimonial.author}</p>
            </div>
          ))}
        </div>
        
        <div className="text-center">
          <a href="#pricing" className="btn-primary mx-auto">
            Junte-se a Eles e Comece a Proteger Sua Vida Digital!
          </a>
        </div>
      </div>
    </section>
  );
};

export default TestimonialsSection;
