
import React from 'react';
import { Mail, Shield, MessageCircle } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-security-darkBlue text-white py-12" id="footer">
      <div className="container mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-center mb-8">
          <div className="flex items-center mb-6 md:mb-0">
            <Shield className="mr-2" size={24} />
            <h3 className="text-xl font-bold">Guia Anti-Golpes</h3>
          </div>
          
          <div className="flex flex-col md:flex-row items-center space-y-4 md:space-y-0 md:space-x-8">
            <a href="mailto:neozbr@yahoo.com.br" className="text-gray-300 hover:text-white flex items-center">
              <Mail className="mr-2" size={18} />
              <span>neozbr@yahoo.com.br</span>
            </a>
            
            <a 
              href="https://wa.me/5535988276359?text=Ol%C3%A1%2C%20tenho%20interesse%20no%20ebook%20e%20gostaria%20de%20perguntar%20sobre" 
              className="text-gray-300 hover:text-white flex items-center"
              target="_blank"
              rel="noopener noreferrer"
            >
              <MessageCircle className="mr-2" size={18} />
              <span>Entre em contato via WhatsApp</span>
            </a>
            
            <a href="https://pay.hotmart.com/F99031339U" className="btn-primary text-sm">
              Compre Agora e Evite Golpes!
            </a>
          </div>
        </div>
        
        <div className="border-t border-gray-700 pt-8">
          <div className="flex justify-center items-center">
            <div className="text-sm text-gray-400">
              © {currentYear} Guia Anti-Golpes. Todos os direitos reservados.
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
