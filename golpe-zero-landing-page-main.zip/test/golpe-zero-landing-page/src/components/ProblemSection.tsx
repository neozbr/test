
import React from 'react';
import { useIsMobile } from '../hooks/use-mobile';

const ProblemSection = () => {
  const isMobile = useIsMobile();
  
  return (
    <section className="py-16 bg-white" id="problem">
      <div className="container mx-auto px-4">
        <h2 className="section-title text-center">Golpes Digitais Estão em Alta!</h2>
        
        <div className="max-w-3xl mx-auto text-center">
          <p className="text-lg md:text-xl mb-8 text-gray-700">
            Se você já caiu em algum golpe ou tem medo de cair, você não está sozinho! 
            As armadilhas digitais estão cada vez mais sofisticadas e a cada dia novas 
            ameaças surgem. Mas a boa notícia é: você pode aprender como se proteger!
          </p>
          
          <div className="bg-security-lightBlue p-6 md:p-8 rounded-lg shadow-lg mb-8">
            <h3 className="text-xl md:text-2xl font-bold mb-4 text-security-blue">
              Com este guia direto ao ponto, você vai:
            </h3>
            <p className="text-lg text-gray-700">
              Aprender a evitar os erros que podem te colocar em risco e como identificar 
              golpes antes que seja tarde. Conhecimento é a sua melhor ferramenta de proteção!
            </p>
          </div>
          
          <a href="https://pay.hotmart.com/F99031339U" className="btn-primary mx-auto">
            Garanta Seu Guia de Proteção Agora!
          </a>
        </div>
      </div>
    </section>
  );
};

export default ProblemSection;
